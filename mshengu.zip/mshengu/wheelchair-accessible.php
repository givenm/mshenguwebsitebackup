<div class="row-fluid main-content-container">
	<div class="services-container">
		<div class="row-fluid blue-heading"><h2>Wheelchair Accessible</h2></div>
		<div class="row-fluid" style="margin: 24px 0 0 0;">
			<div class="span6 left-blue-border">
				<p style="margin: -5px 0 0 0;">Provision for individuals who require special sanitation facilities are met with our wheelchair accessible units.</p>
				<p style="margin: 31px 0 0 0;">These units offer comfort and convenience with no trapping points, wider door opening and its non-slip floor grants easy and secure access for the wheel chair.</p>				
				<p style="margin: 31px 0 0 0;">The unit is a larger in size which includes a number of features  making it ideal for individuals in need of special sanitation requirements.</p>
				
				<p style="margin: 31px 0 0 0;">The unit is designed without any structural barriers that might impede access while its spacious interior allows for the admission of a person in a wheelchair with an attendant.</p>
			</div>
			<div class="span6">
				<?php if( function_exists( 'sliceshow_slideshow' ) ) { sliceshow_slideshow( 130); } ?>
			</div>
		</div>
		
		<div class="row-fluid" style="margin: 31px 0 0 0;">
			<div class="span6">
				<img style="margin: 0 0 0 0; width: 89%;" src="/wp-content/uploads/wheelchair-accessible-table-1.png" />
			</div>
			<div class="span6">
				<img style="margin: 0 0 0 32px; width: 89%;" src="/wp-content/uploads/wheelchair-accessible-table-2.png" />
			</div>
		</div>
		
		<div class="row-fluid" style="margin: 31px 0 31px 0;">
			<div class="span6">
				<img style="margin: 0 0 0 0; width: 89%;" src="/wp-content/uploads/wheelchair-accessible-table-3.png" />
			</div>
			<div class="span6">
				<img style="margin: 0 0 0 32px; width: 89%;" src="/wp-content/uploads/wheelchair-accessible-table-4.png" />
			</div>
		</div>
	</div>
</div>