<div class="row-fluid main-content-container" style="min-height: 513px;">
	<div class="services-container">		
		<div class="row-fluid blue-heading"><h2>Black Economic Empowerment</h2></div>
		<div class="row-fluid">
			<div class="span12" >
				<p>Mshengu Toilet Hire C.C is a proudly Level 3 empowerment contributor company in terms of the DTI Codes of Good Practice on Broad-Based Black Economic Empowerment. Please access the link below to view our company’s 2013 BBBEE rating certificate.</p>				
				<p style="margin: 20px 0 0 0;"> <a href="/wp-content/uploads/Mshengu-Toilet-Hire-BEE-Certificate-2013.pdf">Download our BEE Certificate.</a></p>
			</div>
		</div>
	</div>
</div>
		