<div class="row-fluid main-content-container">
	<div class="services-container" style="padding-left: 70px;">		
		<div class="row-fluid blue-heading" ><h2>Health, Saftey, Environment and Quality</h2></div>
		<div class="row-fluid">
			<div class="span8">						
				<p style="margin: 20px 0 0 0;" class="heighten">It is the policy of Mshengu Toilet Hire to be compliant with the Occupation Health and Safety Act, to conduct all business activities in a responsible manner, which assures the health, safety and security of people, preservation of the environment, and quality of the product/services.</p>
				<p style="margin: 36px 0 0 0;">It is our policy:</p>
				<p style="margin: 10px 0 0 0;">
					<ul class="hseq-ul">
						<li>To maintain, as far as is reasonably possible a working environment that is safe and without risk to the health of the employees;</li>
						<li>To ensures that all employees are competent to carry out (or undertake or complete) their tasks through training, information, instruction and consultation;</li>
						<li>That all employees undergo annual medical assessments to ensure continuity and continued risk control;</li>						
						<li>To Identify hazards in all operational activities and seeks to control them;</li>
						<li>To procure and utilize approved products and chemicals which is of the highest standard and quality and environmentally friendly;</li>
						<li>Communicating openly with its stakeholders to ensure an understanding of our HSEQ policies, standards, programs and performance;</li>
						<li>Be committed to complying with defined requirements and procedures as set out in the Occupational Health and Safety Act.</li>
					</ul>
				</p>
				<p style="margin: 41px 0 0 0;" class="heighten">This policy is subject to continual improvement and is periodically reviewed to ensure suitability, adequacy and effectiveness in respect of the impacts and risks arising from our activities.</p>				
			</div>
			<div class="span4">
				<img style="width: 180px; margin-left: 25px; margin-top: 17px;" src="/wp-content/uploads/hseq.jpg" />
			</div>			
		</div>		
	</div>
</div>
		