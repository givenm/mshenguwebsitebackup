<div class="row-fluid" style="min-height: 520px">
<?php if(isset($_POST['mapping'])): ?>
	
	<?php
	
	
	$url = 'http://kmis.mshengutoilethire.co.za/mshengu/web/' . $_POST['mapping'];
	
	unset($_POST['mapping']); //remove mapping because its use is no longer needed.
	$query_string = http_build_query($_POST);
	
	//open connection
	$ch = curl_init($url);
	
	//set the url, number of POST vars, POST data
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
	curl_setopt($ch, CURLOPT_POSTFIELDS, $query_string);
	curl_setopt($ch, CURLOPT_FORBID_REUSE, TRUE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,0); 
	curl_setopt($ch, CURLOPT_TIMEOUT, 400); //timeout in seconds
	
	//for authentication
	//curl_setopt($ch, CURLOPT_USERPWD, 'admin:admin');
	//curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	
	
	//execute post
	$result = curl_exec($ch);
	
	$error = curl_error($ch);
	
	//close connection
	curl_close($ch);
	
	?>
	
	<div class="row-fluid">
		<div class="span8 offset2 well" style="text-align: center;">
		<?php 	if($result == 'Received..'){
				echo '<div class="row-fluid" style="color: #9E9C9C;">Thank you for your submission. We will attend to your submission within 24hrs.</div>';
			}else{
				$to = 'givenmjay@gmail.com';
				$subject = "Error in API";
				$message = 'An error has occured in the Mshengu website api.php file when a customer was submiting a form. The error is: ' . $error . '
Form data: ' . $query_string;
				$from = "givenmjay@gmail.com";
				$headers = "From:" . $from;
				mail($to,$subject,$message,$headers);
				echo '<div class="row-fluid" style="color: red;">There was a problem with your submission. An email has been sent to our technical team to resolve the problem. Thank you for your patience.</div>';
			}
			?>
			
		</div>
	</div>
	<div class="row-fluid">
		<div class="span10" style="text-align: right;">
				<a href="//mshengutoilethire.co.za" class="btn btn-primary">Return to website</a>		
		</div>
	</div>
<?php else :?>
	<div class="row-fluid">
		<div class="span8 offset2 well" style="text-align: center;">
			<div class="row-fluid" style="color: red;">Only requests via form submission are handled here. Thank you.</div>			
		</div>
	</div>
	<div class="row-fluid">
		<div class="span10" style="text-align: right;">
				<a href="//mshengutoilethire.co.za" class="btn btn-primary">Return to website</a>		
		</div>
	</div>
<?php endif ?>
</div>