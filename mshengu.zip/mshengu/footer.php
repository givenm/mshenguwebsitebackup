	<div class="row-fluid footer">
		<div class="row-fluid footer-links-container">
			<a href="/">Home</a> <span class="footer-link-seperator">/</span> 
			<a href="/services">Services</a> <span class="footer-link-seperator">/</span> 
			<a href="/products">Products</a> <span class="footer-link-seperator">/</span> 
			<a href="/about-us">About Us</a> <span class="footer-link-seperator">/</span> 
			<a href="/terms-of-use">Terms of Hire</a> <span class="footer-link-seperator">/</span> 
			<a href="contact-us">Contact Us</a>
		</div>
		
		<div class="row-fluid copyright">
			Copyright <a href="/">&copy 2013 www.mshengutoilethire.co.za</a>
		</div>
		
		<div class="row-fluid margino">
			<i>Website created  by <a href="http://marginmentor.co.za/"><b>Margin Mentor</b></a></i>
		</div>
	</div>
</div> <!-- Closing for Container-->
<div id="image-load" style="display: none;"><img src="/wp-content/uploads/ajax-loader-.gif"/> </div>
<!-- Modal for clearing fields-->
<div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3 id="myModalLabel"><img src="/wp-content/uploads/warning.jpg"/> Warning</h3>
		</div>
	<div class="modal-body">
		<p>
			Are you sure you want to clear all entered fields?
		</p>
	</div>
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal" aria-hidden="true">No</button>
		<button class="btn btn-primary reset-allowed" data-dismiss="modal" aria-hidden="true">Yes</button>
  	</div>	
</div>
<?php if ( is_page("rfq")):?>
<!-- Modal for clearing fields-->
<div id="errorModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
			<h3 id="myModalLabel"><img src="/wp-content/uploads/warning.jpg"/> Information</h3>
		</div>
	<div class="modal-body">
		<p>
			There was a problem with your submission to our system and we have been alerted. Our team will rectify the problem. You can contact us if the problem still exists after 24hrs. <br><br>Thank you for your patience.
		</p>
	</div>
	<div class="modal-footer">
		<button class="btn" data-dismiss="modal" aria-hidden="true">OK</button>
  	</div>	
</div>
<?php endif?>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/liteaccordion.jquery.min.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/ddmenu.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/jquery-ui-1.10.3.custom.min.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/jquery.flip.min.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/jquery.pause.min.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/jquery.marquee.min.js"></script>
<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/custom-scripts.js"></script>

<?php	
		if(is_home()){
			echo'<script type="text/javascript">$("#menu-0").addClass("active");</script>';
		}else if (is_page('services') || is_page('toilet-hire') || is_page('septic-tanks') || is_page('janitorial')){
			echo'<script type="text/javascript">$("#menu-1").addClass("active");</script>';
		}else if (is_page('products') || is_page('basic-range') || is_page('standard-range') || is_page('executive-range') || is_page('wheelchair-accessible')){
			echo'<script type="text/javascript">$("#menu-2").addClass("active");</script>';
		}else if(is_page('about-us') || is_page('our-history') || is_page('hseq') || is_page('csi') || is_page('clients') || is_page('bee-certification')){
			echo'<script type="text/javascript">$("#menu-3").addClass("active");</script>';
		}
		
?>		

		<?php if(is_page('contact-us')  || is_page('contact-form') || is_page('incident-report-form') || is_page('supplier-registration') || is_page('rfq') || is_page('request-a-quote')):?>
			<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/validate-fields.js"></script>	
			<script type="text/javascript" src="<?php bloginfo( 'template_directory' ) ?>/javascripts/json-formatter.js"></script>
			<script type="text/javascript">
				jQuery.validator.addMethod('customphone', function (value, element) {
					return this.optional(element) || /^\d{3} \d{3} \d{4}$/.test(value);
				}, "Please enter a valid Phone Number with format XXX XXX XXXX");
				
				jQuery.validator.addMethod('customfax', function (value, element) {
					return this.optional(element) || /^\d{3} \d{3} \d{4}$/.test(value);
				}, "Please enter a valid Fax Number with format XXX XXX XXXX");
				
				jQuery.validator.addMethod('customtel', function (value, element) {
					return this.optional(element) || /^\d{3} \d{3} \d{4}$/.test(value);
				}, "Please enter a valid Telephone Number with format XXX XXX XXXX");
				
				jQuery.validator.addMethod('custommobile', function (value, element) {
					return this.optional(element) || /^\d{3} \d{3} \d{4}$/.test(value);
				}, "Please enter a valid Mobile Number with format XXX XXX XXXX");
			
				$(document).ready(function(){
				
					
				
					$("#menu-4").addClass("active"); 
					
					function validateForm(){
						var d = new Date();
			                        var currentYear = d.getFullYear();
						validate = $("#form").validate({
							rules: {
								contactName: {
									minlength: 2,
									required: true
								},
								contactPersonFirstname: {
									minlength: 2,
									required: true
								},
								contactPersonLastname: {
									minlength: 2,
									required: true
								},
								contactPerson: {
									required: true
								},
								clientName: {
									minlength: 2,
									required: true
								},
								eventDate: {
									required: true,
									date: true	
								},
								quantityRequired: {
									minlength: 2,
									required: true,
									digits: true
								},							
								rfqNumber: {
									required: true
								},
								companyName: {
									minlength: 2,
									required: true
								},
								companyregistrationnumber: {
									minlength: 2,
									required: true
								},
								yearEstablishment: {
									minlength: 4,
									maxlength: 4,
									required: true,
									digits: true,
									range: [0000, currentYear ]
									
								},
								chiefExecutiveFirstname: {
									minlength: 2,
									required: true
								},
								chiefExecutiveLastname: {
									minlength: 2,
									required: true
								},								
								chiefExecutive: {
									minlength: 2,
									required: true
								},
								vatRegistrationNumber: {
									minlength: 2,
									required: {
										depends: function(element) {
											return $(".hasVat").is(":checked")
										}
									}
								},
								addressLine1: {
									minlength: 2,
									required: true
								},
								city: {
									minlength: 2,
									required: true
								},
								postalCode: {
									minlength: 2,
									required: true
								},
								
								email: {
								<?php if ( !is_page('incident-report-form')):?> 
									required: true,
								<?php endif?>
									email: true
								},
								
								emailNonRequired: {
									email: true
								},	
								phone: {
									required: true,
									customphone: true
								},			
								telephoneNumber: {
									required: true,
									customtel: true
								},																	
								telephoneNumberNonRequired: {
									customtel: true
								},			
								mobileNumber: {
									required: true,
									custommobile: true
								},
								contactNumber: {
									required: true,
									customphone: true
								},
								faxNumber: {
									customfax: true
								},
								billingAddress: {
									minlength: 2,
									required: true
								},
								deliveryAddress: {
									minlength: 2,
									required: true
								},							
								bank: {
									required: true
								},							
								accountNumber: {
									minlength: 4,
									required: true,
									digits: true
								},							
								branchCode: {
									minlength: 4,
									required: true
								},
								RQNumber: {
									minlength: 2,
									required: true
								},							
								message: {
									minlength: 20,
									required: true
								},
								remarks: {
									minlength: 20,
									required: false
								},
								comment: {
									minlength: 20,
									required: false
								},
								incidentType: {
									required: true
								},
								companyType: {
									required: true
								},
								validityOfQuote: {
									required: true
								},
								paymentTerms: {
									required: true								
								},
								typeOfEvent: {
									required: true								
								},							
								toiletsRequired: {
									required: true								
								},
								deliveryDate: {
									required: true,
									date: true								
								},
								collectionDate: {
									required: true,
									date: true									
								},
								acceptConditions: {
									required: true								
								},
								eventType: {
									required: true
								},
								toiletsRequired1: {
									required: true
								},								
								quantityRequired1: {
									required: true
								},
								additionalQuantityRequired1: {
									required: {
										depends: function(element) {
											return $("#additionalToiletsRequired1").val() != ""
										}
									},
									digits: true
								},
								additionalToiletsRequired1: {
									required: {
										depends: function(element) {
											return $("#additionalQuantityRequired1").val() != ""
										}
									}
								},
								additionalQuantityRequired2: {
									required: {
										depends: function(element) {
											return $("#additionalToiletsRequired2").val() != ""
										}
									},
									digits: true
								},
								additionalToiletsRequired2: {
									required: {
										depends: function(element) {
											return $("#additionalQuantityRequired2").val() != ""
										}
									}
								},
								numberOfJanitors: {
									digits: true,
									required: {
										depends: function(element) {
											return $(".frequencyCheckbox:checked").length > 0
										}
									}
								},
								numberOfToiletRolls: {
									digits: true
								},
								vendorCategory: "required",
								webSite: {
									url: true
								},
								"item[0]": {
									required: true								
								},
								"itemNumber[0]": {
									required: true								
								},
								"qty[0]": {
									required: true,
									digits: true								
								},
								"unit[0]": {
									required: true,
									digits: true								
								},
								"unitPrice[0]": {
									required: true,
									digits: true								
								},
								"subTotal[0]": {
									required: true,
									digits: true								
								}
								
						    },
							highlight: function(element) {
								$(element).closest('.control-group').removeClass('success').addClass('error');
							},
							success: function(element) {
								element.closest('.control-group').removeClass('error');
							},
							messages: {
								incidentType: 'Select an option before submit.',
								toiletsRequired1: 'Select an option before submit.',
								vendorCategory: 'Select an option before submit.',
								companyType: 'Select an option before submit.',
								validityOfQuote: '<div class="offset8">Select an option before submit.</div>',
								paymentTerms: '<div class="offset8">Select an option before submit.</div>',
								typeOfEvent: 'Select an option before submit.',
								additionalToiletsRequired1: 'Select an option else remove Quantity ->',
								additionalQuantityRequired1: 'Digits only! Enter Quantity else Select Additional Toilets Required.',
								additionalToiletsRequired2: 'Select an option else remove Quantity ->',
								additionalQuantityRequired2: 'Digits only! Enter Quantity else Select Additional Toilets Required.',
								numberOfJanitors: 'Select Service Frequency for the Janitors else remove the Janitors number. Only numbers allowed.',
								vatRegistrationNumber: 'Please eneter VAT Registration Number else unselect above',
								webSite: 'Please enter valid URL. NB: It should start with http:// OR https://'
							}
							<?php if ( !is_page("rfq")):?>,
							submitHandler: function(form) {
								$('#image-load').fadeIn();
								form.submit();
							}
							<?php endif?>
							<?php if ( is_page("rfq")):?>,
							submitHandler: function(form) {
								$('#image-load').fadeIn();
								$.ajax({
									url: 'validate',
									type: 'GET',
									dataType: 'text',
									data: {rfqNumber: $('input[name="rfqNumber"]').val()},
									success: function(data, textStatus, jqXHR) {
										$('#image-load').fadeOut();
										data = $.trim(data)										
									    	var errors;
										if (data == 'false') { //handle when the rfqNumber has not been found
											errors = { rfqNumber: "Your RFQ Number <b>'" + $('input[name="rfqNumber"]').val() + "'</b> does not exist on our System. Please re-check your email for the RFQ Number." };
											validate.showErrors(errors); 
											$('html, body').animate({
												scrollTop: 0
											}, 1000, function(){
												$('input[name="rfqNumber"]').focus();
											});    
											$('input[name="rfqNumber"]').rules('add', {
											        required: true,
											        notEqual: $('input[name="rfqNumber"]').val(),
											        messages: {
													required: "This field is required.",
													notEqual: "Your RFQ Number <b>'" + $('input[name="rfqNumber"]').val() + "'</b> does not exist on our System. Please re-check your email for the RFQ Number."
												}
											});       
										}else if(data == 'true'){//submit when rfqNumber is valid i.e. exists in kmis
											$('#image-load').fadeOut();								
											form.submit(); 
										} else{ //handle when the checking of rfq api has an error
											$('#image-load').fadeOut();
											$('#errorModal').modal('show');
										}  
										$('#image-load').fadeOut(); 
									},
									error: function(jqXHR, textStatus, errorThrown) {
										$('#image-load').fadeOut();
									    	alert('Error: ' + jqXHR.statusText + ' ' + textStatus + ' ' + errorThrown);
									}
								});								
							}
														
							<?php endif?>
							
						});
					}	
					
					validateForm(); /*Register the validations*/
					<?php if ( is_page("rfq")):?>
						$('button[type="submit"]').mouseenter(function(){
							$('input[name="rfqNumber"]').rules('remove', 'notEqual');
						});
						
						$("body").on("keypress", function (e) {
							if(e.keyCode == 13){
								$('input[name="rfqNumber"]').rules('remove', 'notEqual');
							}
						});
						
					<?php endif?>
														
					$(".frequencyCheckbox").change(function(){						
						if($(this).val() == 'false'){
							$(this).val('true');
						}else{
							$(this).val('false');
						}
						
					});
				});
			</script>					
		<?php endif?>

<?php if ( is_page('request-a-quote')):?> 
		<script type="text/javascript">
			$('.datepicker').datepicker();
		</script>	
<?php endif?>

<?php if ( is_page('clients')):?> 
	<script type="text/javascript">	
	
		$(document).ready(function(e) {	
	        
		        /*marqee text*/	       
			
			/**
			 * Example of starting a plugin with options.
			 * I am just passing all the default options
			 * so you can just start the plugin using $('.marquee').marquee();
			*/
			var mq = $('.marquee').marquee({
				//speed in milliseconds of the marquee
				speed: 6000,
				//gap in pixels between the tickers
				gap: 900,
				//time in milliseconds before the marquee will start animating
				delayBeforeStart: 0,
				//'left' or 'right'
				direction: 'left',
				//true or false - should the marquee be duplicated to show an effect of continues flow
				duplicated: true,
				//on hover pause the marquee - using jQuery plugin https://github.com/tobia/Pause
				pauseOnHover: true,
				//on cycle pause the marquee
				pauseOnCycle: false
			});				
			
			/*End of marqee text*/
		
		});
	
	</script>
<?php endif?>