<div class="row-fluid main-content-container">		
	<div class="row-fluid blue-heading"><h2>INCIDENT REPORT FORM</h2></div>
	<div class="row-fluid">
		<div class="span5">
			<div class="row-fluid">
				<img  style="margin: 31px 0 0 0;" src="/wp-content/uploads/incident-form-report.jpg">
			</div>
			<div class="row-fluid" style="margin: 31px 0 0 0; border-top: solid 1px rgb(192, 192, 192); border-bottom: solid 1px rgb(192, 192, 192); padding-top: 6px;">
				<p>Please complete the contact form with as much detail as possible!</p>
			</div>
			<div class="row-fluid blue-heading" style="margin: 31px 0 0 0;"><h4>CONTACT MSHENGU TOILET HIRE</h4></div>
			<div class="row-fluid" style="margin: 10px 0 0 0;">
				<p style="margin: 0 0 20px 0;">For any further information <br>please contact us on:</p>
				<h4 class="blue-heading">Service Operations:</h4>
				<p>
				Tel: 021 691 3793<br>
				Fax: 021 691 3831<br>
				Email: info@mshengutoilethire.co.za</p>					
			</div>
		</div>
		<div class="span7">
			<div class="row-fluid blue-heading" style="margin: 0 0 10px 0; border-bottom: 1px dotted rgb(192, 192, 192);"><h5>Incident Details</h5></div>
			<form class="" id="form" action="/thank-you" method="post">
				<input type="hidden" name="mapping" value="incident"/>
				<input type="hidden" name="reason" value="An Incident"/>
				<input type="hidden" value="" id="comboChecker"/>
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="clientName">Client Name <span class="required">*</span></label>
					</div>
					<div class="control-group span9">						
						<div class="controls">
							<input class="span12" type="text" name="clientName" id="clientName" />
						</div>
					</div>
				</div>
				
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="contactPerson">Contact Person <span class="required">*</span></label>
					</div>
					<div class="control-group span9">						
						<div class="controls">
							<input class="span12" type="text" name="contactPerson" id="contactPerson" />
						</div>
					</div>
				</div>				
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="email">Email</label>
					</div>
					<div class="control-group span9">						
						<div class="controls">
							<input class="span12" type="text" name="email" id="email" />
						</div>
					</div>
				</div>
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="contactNumber">Contact Number <span class="required">*</span></label>						
					</div>
					<div class="control-group span9">
						<div class="controls">
							<input class="span12" name="contactNumber" id="contactNumber" type="text" />
						</div>
					</div>
				</div>				
				
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="incidentType">Incident Type <span class="required">*</span></label>						
					</div>
					<div class="control-group span9">
						<div class="controls">
							<select class="span12 requiredCombo" name="incidentType" id="incidentType" type="text">
								<option value="">--Please Choose an Option--</option>
								<option value="Arson">Arson</option>
								<option value="Community Protest">Community Protest</option>
								<option value="Damage">Damage</option>
								<option value="Theft">Theft</option>
								<option value="Not Serviced">Not Serviced</option>
								<option value="Vandalism">Vandalism</option>
								<option value="Incorrect Placement">Incorrect Placement</option>
								<option value="Non-Delivery">Non-Delivery</option>
								<option value="Non-Collection">Non-Collection</option>
							</select>
						</div>
					</div>
				</div>				
				
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="site">Site</label>
						
					</div>
					<div class="control-group span9">
						<div class="controls">
							<input class="span12" name="site" id="site" type="text" />
						</div>
					</div>
				</div>
				
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="suburb">Suburb</label>
						
					</div>
					<div class="control-group span9">
						<div class="controls">
							<input class="span12" name="suburb" id="suburb" type="text" />
						</div>
					</div>
				</div>
				
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="toilet-type">Toilet Type </label>
						
					</div>
					<div class="control-group span9">
						<div class="controls">
							<select class="span12" name="toiletType" id="toilet-type" type="text" >
								<option>--Please Choose an Option--</option>
								<option>Basic Atlas</option>
								<option>Standard Non-Flush</option>
								<option>Executive Flush</option>
								<option>Executive Flush & Hand Basin</option>
								<option>Wheel Chair Accessible</option>								
							</select>
						</div>
					</div>
				</div>	
				
				<div class="row-fluid">			
					<div class="control-group span3">
						<label class="control-label" for="remarks">Incident Remarks </label>
					</div>
					<div class="control-group span9">
						<div class="controls">
							<textarea style="max-width: 402px; width: 402px;" placeholder="Your message must be greater than 20 characters" name="remarks" id="remarks" rows="6" class="span12"></textarea>
						</div>
					</div>
				</div>
				
				<div class="row-fluid" style="margin: 20px 0 20px 0;">			
					<div class="control-group span5">
						<span class="required">*</span> <i>Indicates a required field!</i>					
					</div>
					<div class="control-group span7">							
							<button type="submit" class="span4 btn btn-primary">SUBMIT</button>
							<button type="button" class="span4 btn reset-btn reset-btn">RESET</button>							
					</div>
				</div>
				
			</form>
		</div>
	
	</div>
</div>