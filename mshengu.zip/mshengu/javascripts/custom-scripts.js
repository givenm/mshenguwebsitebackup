$(document).ready(function() {
	 

	/*Horizontal Accordion on home page*/	
	$('#one-lite-accordion').liteAccordion({
		enumerateSlides : true,
		firstSlide : 1,
		linkable : true,
		easing: 'easeInOutQuart',
		autoPlay: true,
		containerWidth : 910,
		containerHeight : 332,
		headerWidth: 53,
		pauseOnHover: true	
		
	}).find('figcaption:first').show();
	
	
	/*end of menu on home page*/	
	
	
	/*Animate to top on footer*/
	$('.back-to-top').click(function() {
		$('html, body').animate({
			scrollTop : 0
		}, 1000);
	});
	/*End: Animate to top on footer*/
		
	/*flip on csr http://lab.smashup.it/flip/*/ 
	$( document ).on('click','#flip-1', function(){		
		$("#flipbox-1").flip({
			direction:'lr',
			content:$("#flipbox-1-temp-1"),
			speed: 400,
			color: '#fff'
		});
	});
	
	$( document ).on('click','#flip-1-revert', function(){	
		$("#flipbox-1").flip({
			direction:'rl',
			content:$("#flipbox-1-temp-2"),
			speed: 400,
			color: '#fff'
		});
	});
	
	$( document ).on('click','#flip-2', function(){		
		$("#flipbox-2").flip({
			direction:'lr',
			content:$("#flipbox-2-temp-1"),
			speed: 400,
			color: '#fff'
		});
	});
	
	$( document ).on('click','#flip-2-revert', function(){	
		$("#flipbox-2").flip({
			direction:'rl',
			content:$("#flipbox-2-temp-2"),
			speed: 400,
			color: '#fff'
		});
	});
	
	$( document ).on('click','#flip-3', function(){
		$('#flip-slider').hide();
		$("#flip-3").css({'width': '399px', 'height': '266px', 'margin-left' : '5px', 'margin-top' : '0px', 'padding-top' : '0px'});		
		$("#flip-3").flip({
			direction:'lr',
			content:$("#flipbox-3-temp-1"),
			speed: 400,
			color: '#fff'
		});
	});
	
	$( document ).on('click','#flip-3-revert', function(){	
		$("#flip-3").flip({
			direction:'rl',
			content:' ',
			speed: 400,
			color: '#fff',
			onEnd: function(){
				$('#flip-slider').show();
				$("#flip-3").css({'width': '381px', 'height': '70px', 'margin-left' : '5px', 'margin-top' : '-71px', 'background-color' : 'transparent'});
			}
		});
	});
	
	$('.backward').click(function(){
		$('.csi-slider').animate({'margin-left': '0'}, 500);
	});
	
	$('.forward').click(function(){
		$('.csi-slider').animate({'margin-left': '-441px'}, 500);		
	});
		
	$('.reset-btn').click(function(){
		$('#myModal').modal('show');		
	});
	
	$('.reset-allowed').click(function(){
		$('#form')[0].reset();
		$(".vatRegistrationNumber").slideUp();
	});
	
	$('#billingAddress').keyup(function(){
		if($('#sameAsBillingAddress').is(':checked')){
			$('#deliveryAddress').val($(this).val());
		}
	});
	
	$('#sameAsBillingAddress').click(function(){
		if($('#sameAsBillingAddress').is(':checked')){
			$('#deliveryAddress').val($('#billingAddress').val());
		}
	});
	
	/*list of details on the rfq page*/
	var inc = 1;
	$('#add-items').click(function(){
		$('.items').append('<div class="span1"><i class="icon-remove" style="margin-top: 8px;"></i></div><div class="row-fluid item-rows"><div class="span3"><input name="item[' + inc + ']" class="span12 item" type="text"/></div><div class="span2"><input name="itemNumber[' + inc + ']" class="span12 itemNumber" type="text"/></div><div class="span1"><input name="qty[' + inc + ']" class="span12 qty" type="text"/></div><div class="span1"><input name="unit[' + inc + ']" class="span12 unit" type="text"/></div><div class="span2"><input name="unitPrice[' + inc + ']" class="span12 unitPrice" type="text"/></div><div class="span2"><input name="subTotal[' + inc + ']" class="span12 subTotal" type="text"/></div></div>');
		inc++;
		$('.item-rows .item, .item-rows .itemNumber').each(function () {
		    $(this).rules('add', {
		        required: true
		    });
		});
		$('.item-rows .qty, .item-rows .unit, .item-rows .unitPrice, .item-rows .subTotal').each(function () {
		    $(this).rules('add', {
		        required: true,
			digits: true							        
		    });
		});
	});
	
	/*Delete row*/
	$( document ).on('click','.icon-remove', function(){	
		$(this).parent().next('.item-rows').remove();
		$(this).parent().remove();
	});
	
	$(".hasVat").change(function(){		
		if($(".vatRegistrationNumber").is(":visible")){
			$(".vatRegistrationNumber").slideUp();
		}else{
			$(".vatRegistrationNumber").slideDown();
		}
		
	});
	
});