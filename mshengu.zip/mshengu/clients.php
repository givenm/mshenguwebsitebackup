<div class="row-fluid main-content-container">
	<div class="services-container" style="min-height: 513px">		
		<div class="row-fluid blue-heading"><h2>Our Clients</h2></div>
		<div class="row-fluid">
			<p style="margin: 20px 0 0 0;">We are proud suppliers to:</p>
		</div>
		<div class="row-fluid ticker-container lines" style="margin: 40px 0 0 0;">			
			<div class="ticker-text marquee" style="width: 925px;">
				<img class="grey-img" src="/wp-content/uploads/client-1.png"/>
				<img class="grey-img" src="/wp-content/uploads/client-2.png"/>
				<img class="grey-img" src="/wp-content/uploads/client-3.png"/>
				<img class="grey-img" src="/wp-content/uploads/client-4.png"/>
				<img class="grey-img" src="/wp-content/uploads/client-5.png"/>
				<img class="grey-img" src="/wp-content/uploads/client-6.png"/>
				<img class="grey-img" src="/wp-content/uploads/client-7.png"/>
				<img class="grey-img" src="/wp-content/uploads/client-8.png"/>
			</div>
		</div>
	</div>
</div>