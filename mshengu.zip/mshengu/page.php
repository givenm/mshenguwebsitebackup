<?php
/**
 * The template for displaying all pages.
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site will use a
 * different template.
 *
 * @package Mshengu
 */
if (!is_page('validate')){
	get_header(); 
}
	
?>
	
	<?php
		if (is_page('validate')){

			get_template_part('checkRfqNumber');

		}else if (is_page('thank-you')){

			get_template_part('api');

		}else if (is_page('services')){

			get_template_part('services');

		}else if (is_page('toilet-hire')){

			get_template_part('toilet-hire');

		}else if (is_page('septic-tanks')){

			get_template_part('septic-tanks');

		}else if (is_page('janitorial')){

			get_template_part('janitorial');

		}else if (is_page('products')){

			get_template_part('products');

		}else if (is_page('basic-range')){

			get_template_part('basic-range');

		}else if (is_page('standard-range')){

			get_template_part('standard-range');

		}else if (is_page('wheelchair-accessible')){

			get_template_part('wheelchair-accessible');

		}else if (is_page('executive-range')){

			get_template_part('executive-range');

		}else if(is_page('about-us')){

			get_template_part('about-us');

		}else if(is_page('our-history')){

			get_template_part('our-history');

		}else if(is_page('hseq')){

			get_template_part('hseq');

		}else if(is_page('csi')){

			get_template_part('csi');

		}else if(is_page('clients')){

			get_template_part('clients');

		}else if(is_page('bee-certification')){

			get_template_part('bee-certification');

		}else if(is_page('contact-us')){

			get_template_part('contact-us');

		}else if(is_page('contact-form')){

			get_template_part('contact-form');

		}else if(is_page('rfq')){

			get_template_part('rfq');

		}else if(is_page('supplier-registration')){

			get_template_part('supplier-registration');

		}else if(is_page('incident-report-form')){

			get_template_part('incident-report-form');

		}else if(is_page('request-a-quote')){

			get_template_part('request-a-quote');
			
		} 
	
	?>

	<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); 		
			the_content(); /*this allows the pages content to be displayed. The content is NOT from a custom get_template_part() method*/
		endwhile; else: ?>
			<p>Sorry, no page called criteria.</p>
	<?php endif; ?>

<?php 
if (!is_page('validate')){
	get_footer(); 
}
 ?>