<div class="row-fluid main-content-container">
	<div class="services-container">
		<div class="row-fluid blue-heading"><h2>Basic Range</h2></div>
		<div class="row-fluid" style="margin: 24px 0 0 0;">
			<div class="span6 left-blue-border">
				<p style="margin: -2px 0 0 0;">The basic non-flush is our most economical solution and is ideally suited for use in informal settlements and construction sites.</p>
				<p style="margin: 31px 0 0 0;">This basic non-flush features a single toilet used in conjunction with chemical agents to mask odours, degrade sold waste for extra comfort and increased sanitation.</p>
				<p style="margin: 31px 0 0 0;">The basic non-flush portable toilet is serviced on a regular basis which includes the cleaning of the toilet, waste removal from the tank and restocking the supplies as needed.</p>
				<p style="margin: 31px 0 0 0;">Portable toilet service frequencies may be scheduled on a daily, weekly or monthly basis. Alternative arrangements can be made for customer specific service requirements.</p>
			</div>
			<div class="span6" style="">
				<?php if( function_exists( 'sliceshow_slideshow' ) ) { sliceshow_slideshow( 110); } ?>
			</div>
		</div>
		
		<div class="row-fluid" style="margin: 31px 0 0 0;">
			<div class="span6">
				<img style="margin: 0 0 0 0; width: 89%;" src="/wp-content/uploads/basic-table-1.png" />
			</div>
			<div class="span6">
				<img style="margin: 0 0 0 32px; width: 89%;" src="/wp-content/uploads/basic-table-2.png" />
			</div>
		</div>
		
		<div class="row-fluid" style="margin: 66px 0 31px 0;">
			<div class="span6">
				<img style="margin: 0 0 0 0; width: 89%;" src="/wp-content/uploads/basic-table-3.png" />
			</div>
			<div class="span6">
				<img style="margin: 0 0 0 32px; width: 89%;" src="/wp-content/uploads/basic-table-4.png" />
			</div>
		</div>
	</div>
</div>