<?php if(isset($_GET['rfqNumber']))
		
	$url = 'http://kmis.mshengutoilethire.co.za/mshengu/web/checkrfqnumber/' . $_GET['rfqNumber'];	
	
	$query_string = http_build_query($_GET);
	
	//open connection
	$ch = curl_init($url);
	
	//set the url, number of POST vars, POST data
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
	curl_setopt($ch, CURLOPT_FORBID_REUSE, TRUE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT ,0); 
	curl_setopt($ch, CURLOPT_TIMEOUT, 400); //timeout in seconds
	
	//for authentication
	//curl_setopt($ch, CURLOPT_USERPWD, 'admin:admin');
	//curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	
	
	//execute get
	$result = curl_exec($ch);
	$error = curl_error($ch);
	//close connection
	curl_close($ch);
	
?>

<?php 	if($result != 'false' && $result != 'true'){
		$to = 'givenmjay@gmail.com';
		$subject = "Error in checkRfqNumber.pbp";
		$message = 'An error has occured in the Mshengu website checkRfqNumber.php file when a customer was submiting a form. The error is: ' . $error;
		$from = "givenmjay@gmail.com";
		$headers = "From:" . $from;
		mail($to,$subject,$message,$headers);
	}else{
		echo $result; //correct data back to ajax
	}
	?>