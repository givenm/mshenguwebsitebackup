<?php
	get_template_part('contact-form');
	
?>