<?php

/*
 * Functions file
 * Includes all necesary files
 *
 * @package custom
 */

/*
register_sidebar( array(
	'id'	=> 'how-it-works',
	'name'	=> __( 'How it Works Widget', 'minimum' ),
	'description'	=> __( 'How it Works Widget that has links of pages from the Home tabs.', 'minimum' ),
) );
*/

function register_my_menus() {
	register_nav_menus(
			array(
				'header-menu' => __( 'Primary Menu' ),				
			)
	);
}


add_action( 'init', 'register_my_menus' );

function clean_custom_menus() {
	$menu_name = 'primary-menu'; // specify custom menu slug
	if ( ($locations = get_nav_menu_locations()) && isset( $locations[$menu_name] ) ) {
		$menu = wp_get_nav_menu_object( $locations[$menu_name] );
		$menu_items = wp_get_nav_menu_items( $menu->term_id );	
		$imageCount = 0;	
		$menu_icons = array(
		"/wp-content/uploads/home-icon.png",
		"/wp-content/uploads/services-icon.png",
		"/wp-content/uploads/product-icon.png",
		"/wp-content/uploads/about-us-icon.png",
		"/wp-content/uploads/contact-us-icon.png"
		);
		
		$opened = false;
    		$menu_list .= '<ul id="menu-bar">';
		foreach ( (array) $menu_items as $key => $menu_item ) {
			$title = $menu_item->title;
			$url = $menu_item->url;
			
			if(!$menu_item->menu_item_parent){ //if parent
				if($opened){
					$menu_list .=	  '</ul>'; //close sub menu
					$menu_list .= '</li>'; //close list item
					$opened = false;
				}
				$menu_list .= '<li id="menu-'. $imageCount .'" class="menuitem"><img src="'. $menu_icons[$imageCount++] .'"/> <a href="'. $url .'">' . $title. '</a>';				
			}else{ //if sub menu
				
				if(!$opened){
					$menu_list .=	  '<ul>'; //open sub menu
					$opened = true;
				}							
				$menu_list .=		'<li><a href="'. $url .'">' . $title . '</a></li>';
				
			}	
			
							
		}		
		$menu_list .=     '</ul>'; //closing for menu list
		
		
	} else {
		 $menu_list = 'no list defined';
	}
	echo $menu_list;
}

?>