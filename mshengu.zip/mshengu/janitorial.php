<div class="row-fluid main-content-container">
	<div class="services-container">		
		<div class="row-fluid blue-heading"><h2>Janitorial Services</h2></div>
		<div class="row-fluid">
			<div class="span12">
				<p>A janitorial service is provided to clients on request. This service is available to maintain highest levels of health and safety. All units hired are maintained and chemically cleaned on a regular basis. The janitorial service is a specialised offering delivered by trained individuals to maintain and clean toilets.</p>				
			</div>
		</div>
		<div class="row-fluid"  style="margin: 5px 0 20px 0;">
			<div class="span11"><img style="margin: 0 0 0 156px;" src="/wp-content/uploads/janitorial-services.jpg"/></div>
		</div
	</div>
</div>
		