<div class="row-fluid">
	<img  style="margin: 31px 0 0 0;" src="/wp-content/uploads/quote-image.jpg">
</div>
<div class="row-fluid" style="margin: 31px 0 0 0; border-top: solid 1px rgb(192, 192, 192); border-bottom: solid 1px rgb(192, 192, 192); padding-top: 6px;">
	<p>Please fill in as much information as possible so as to enable us  to give you the most accurate quote!</p>
</div>
<div class="row-fluid blue-heading" style="margin: 31px 0 0 0;"><h4>CONTACT MSHENGU TOILET HIRE</h4></div>
<div class="row-fluid" style="margin: 10px 0 0 0;">
	<p>For any further information <br>please contact us on:</p>
	<p class="blue-heading"><b>Service Operations:</b></p>
	<p>
	Tel: 021 691 3793<br>
	Fax: 021 691 3831<br>
	Email: info@mshengutoilethire.co.za</p>					
</div>