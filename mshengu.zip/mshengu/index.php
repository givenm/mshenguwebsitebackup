<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package Margin Mentor
 */
get_header();

?>
	
<div class="accordion-container">
	<div id="one-lite-accordion" class="liteAccordion light" style="width: 925px; height: 320px;">
		<ol>
			<li class="slide">
			    <h2 class=""><span>OUR TEAM</span></h2>
			    <div style="width: 715px; left: 0px;">
			        <div id="content-a" class="row accordion-content" style="margin-left: -1px;"></div>
			    </div>
			</li>
			<li class="slide">
			    <h2 class=""><span>SANITATION EQUIPMENT</span></h2>
			    <div style="width: 715px; left: 48px;">
			         <div id="content-b" class="row accordion-content" style="margin-left: -1px;"></div>
			    </div>
			</li>
			<li class="slide">
			    <h2 class="" ><span>SERVICE FLEET</span></h2>
			    <div style="width: 715px; left: 96px;">
			         <div id="content-c" class="row accordion-content" style="margin-left: -1px;"></div>
			    </div>
			</li>
			<li class="slide">
			    <h2 class="" ><span>OUR  PRIORITY</span></h2>
			    <div style="width: 715px; left: 144px;">
			         <div id="content-d" class="row accordion-content" style="margin-left: -1px;"></div>
			    </div>
			</li>				
		</ol>
		<noscript>
		&lt;p&gt;Please enable JavaScript to get the full experience.&lt;/p&gt;
		</noscript>
	</div>
</div>



<div class="content-bottom-container">
	<div class="row-fluid content-bottom">
		<div class="row-fluid upper-content">
			<div class="row-fluid"><h3 class="upper-content-heading">YOUR  SANITATION OUR  PRIORITY</h3></div>
			<div class="row-fluid" align="center"><h4>Need portable sanitation? Mshengu Toilet Hire will serve your needs.</h4></div>
			<div class="row-fluid" class="upper-content-para ">
				<div class="row-fluid para">Mshengu Toilet Hire has been serving the Western Cape community since 2000.</div>
				<div class="row-fluid para">
					Our goal is to provide communities and clients with courteous, expedient and professional 
				</div>
				<div class="row-fluid para">
					service of the highest standard.
				</div>
			</div>
		</div>
		<div class="row-fluid lower-content" style="position:relative; margin-left: -20px;">
			<a href="/toilet-hire/#construction" class="home-links " style="left: 29px;"></a>
			<a href="/toilet-hire/#special-events" class="home-links " style="left: 348px;"></a>
			<a href="/toilet-hire/#informal-settlements" class="home-links " style="left: 668px;"></a>
			<div class="span12" style="z-index: 10;"><img style="max-width: 101%;" src="/wp-content/uploads/home-ribbon.jpg"/></div>
			
		</div>
	</div>
</div>

<?php get_footer(); ?>
	