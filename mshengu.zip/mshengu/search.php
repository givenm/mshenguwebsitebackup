<?php get_header();
	

	// The Query
	global $query_string;

	$query_args = explode("&", $query_string);
	$search_query = array();
	
	foreach($query_args as $key => $string) {
		$query_split = explode("=", $string);
		$search_query[$query_split[0]] = urldecode($query_split[1]);
	} // foreach
	
	$query = new WP_Query($search_query);
	
	// The Loop
	if ( $query->have_posts() ) {
		while ( $query->have_posts() ) {
			$query->the_post();
			echo '<li>' . get_the_title() . '</li>';
		}
	} else {
		// no posts found
		echo 'No Search results found!';
	}
	/* Restore original Post Data */
	wp_reset_postdata();

 get_footer(); ?>