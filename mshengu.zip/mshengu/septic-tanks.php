<div class="row-fluid main-content-container">
	<div class="services-container">		
		<div class="row-fluid blue-heading"><h2>Septic Tank Pumping</h2></div>
		<div class="row-fluid">
			<div class="span12">
				<p>It is vitally important that septic tank systems receive proper attention. When sludge and scum have accumulated to a level where it might start discharging the effluent, the tank should be emptied and the sludge removed. This prevents and avoids possible permanent damage to the surrounding percolation <br>system. </p>				
				<p style="margin: 20px 0 0 0;" >Mshengu Toilet Hire provides a vacuum suction service for septic tanks and it is also important to note that the tank should not be treated with any form of disinfectant. In order that the digesting process continues when the tank is put back into service a small quantity of sludge will be retained to serve as a starter.</p>
			</div>
		</div>
		<div class="row-fluid">
			<div class="span12"><img  style="margin: 37px 0 20px 132px;" src="/wp-content/uploads/septic-tanks.jpg"/></div>
		</div
	</div>
</div>
		