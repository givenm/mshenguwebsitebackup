<?php
	get_template_part('toilet-hire');
?>	