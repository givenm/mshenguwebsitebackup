<div class="row-fluid main-content-container">		
	<div class="row-fluid blue-heading"><h2>CONTACT FORM</h2></div>
	<div class="row-fluid">
		<div class="span5">
			<div class="row-fluid">
				<img  style="margin: 31px 0 0 0;" src="/wp-content/uploads/contact.jpg">
			</div>
			<div class="row-fluid" style="margin: 31px 0 0 0; border-top: solid 1px rgb(192, 192, 192); border-bottom: solid 1px rgb(192, 192, 192); padding-top: 6px;">
				<p>Please complete the contact form with as much detail as possible!</p>
			</div>
			<div class="row-fluid blue-heading" style="margin: 31px 0 0 0;"><h4>CONTACT MSHENGU TOILET HIRE</h4></div>
			<div class="row-fluid" style="margin: 10px 0 0 0;">
				<p style="margin: 0 0 20px 0;">For any further information <br>please contact us on:</p>
				<h4 class="blue-heading">Service Operations:</h4>
				<p>
				Tel: 021 691 3793<br>
				Fax: 021 691 3831<br>
				Email: info@mshengutoilethire.co.za</p>					
			</div>
			<div class="row-fluid" style="margin: -3px 0 0 0;">
				<p>
					<div class="blue-heading">Contact Persons:</div>
					<b>Hilton Cupido</b> (General Manager)<br>
					<b>Benjamin Milandou-Loukeba</b> (Field Service Manager)<br>
					<b>Sydney Esau</b> (Operations Manager)<br>
					<b>Samantha Minnaar</b> (Office Administrator)<br>
				</p>
			</div>
			<div class="row-fluid" style="margin: 0px 0 0 0;">				
				<p>
					<div class="blue-heading">Operating Hours:</div>
					Monday- Friday 07h00 – 16h00<br>
					Saturdays 07h00 – 13h00<br>
				</p>
			</div>
			<div class="row-fluid" style="margin: 40px 0 0 0;">
				<h4 class="blue-heading"> Administration:</h4>
				<p>
					Service Requests / Finance<br>
					Tel:   021 637 0412<br>
					Fax : 021 633 1145
				</p>
			</div>
			<div class="row-fluid" style="margin: -3px 0 0 0;">
				<p>
					<div class="blue-heading">Contact Person:</div>
					<b>Soraya Kader</b> (Senior Office Administrator)
				</p>
			</div>
			<div class="row-fluid" style="margin: 0 0 0 0;">				
				<p>
					<div class="blue-heading">Operating Hours:</div>
					Monday- Friday 07h00 - 16h00
				</p>
			</div>		
		</div>
		<div class="span7">			
			<div class="row-fluid blue-heading" style="margin: 0 0 10px 0; border-bottom: 1px dotted rgb(192, 192, 192);"><h5>Your Details</h5></div>
			<form class="" id="form" action="/thank-you" method="post">
				<input type="hidden" name="mapping" value="contact"/>
				<input type="hidden" name="reason" value="A Contact"/>
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="contactPersonFirstname">Firstname<span class="required">*</span></label>
					</div>
					<div class="control-group span9">						
						<div class="controls">
							<input class="span12" type="text" name="contactPersonFirstname" id="contactPersonFirstname">
						</div>
					</div>	
				</div>
				
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="contactPersonLastname">Lastname<span class="required">*</span></label>
					</div>
					<div class="control-group span9">						
						<div class="controls">
							<input class="span12" type="text" name="contactPersonLastname" id="contactPersonLastname">
						</div>
					</div>	
				</div>
				
				<div class="row-fluid">			
					<div class="control-group span3">
						<label class="control-label" for="company">Company </label>
					</div>
					<div class="control-group span9">
						<div class="controls">
							<input class="span12" type="text" name="company" id="company" />
						</div>
					</div>
				</div>
				
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="email">Email <span class="required">*</span></label>
					</div>
					<div class="control-group span9">						
						<div class="controls">
							<input class="span12" type="text" name="email" id="email" />
						</div>
					</div>
				</div>
				
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="phone">Phone <span class="required">*</span></label>						
					</div>
					<div class="control-group span9">
						<div class="controls">
							<input class="span12" name="phone" id="phone" type="text" />
						</div>
					</div>
				</div>
				
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="faxNumber">Fax Number</label>
						
					</div>
					<div class="control-group span9">
						<div class="controls">
							<input class="span12" name="faxNumber" id="faxNumber" type="text" />
						</div>
					</div>
				</div>
				
				<div class="row-fluid">
					<div class="control-group span3">
						<label class="control-label" for="hearAboutUs">How Did You Hear About Us?</label>
						
					</div>
					<div class="control-group span9">
						<div class="controls">
							<input class="span12" name="hearAboutUs" id="hearAboutUs" type="text" />
						</div>
					</div>
				</div>				
				
				
				<div class="row-fluid">			
					<div class="control-group span3">
						<label class="control-label" for="message">Message <span class="required">*</span></label>
					</div>
					<div class="control-group span9">
						<div class="controls">
							<textarea style="max-width: 402px; width: 402px;" placeholder="Your message must be greater than 20 characters" name="message" id="message" rows="6" class="span12"></textarea>
						</div>
					</div>
				</div>
				
				<div class="row-fluid" style="margin: 20px 0 20px 0;">			
					<div class="control-group span5">
						<span class="required">*</span> <i>Indicates a required field!</i>					
					</div>
					<div class="control-group span7">							
							<button type="submit" class="span4 btn btn-primary">SUBMIT</button>
							<button type="button" class="span4 btn reset-btn">RESET</button>							
					</div>
				</div>
				
			</form>
		</div>
	
	</div>
</div>