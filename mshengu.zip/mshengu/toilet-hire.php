<div class="row-fluid main-content-container">
	<div class="services-container">		
		<div class="row-fluid blue-heading"><h2>Toilet Hire</h2></div>
		<div class="row-fluid">
			<div class="span12">
				Mshengu Toilet Hire provides non flush and flush portable chemical toilets for daily, medium and long-term hiring. We offer our products and services to informal settlement, construction sites and special events.
			</div>
		</div>
		
		<div class="row-fluid blue-heading" style="margin: 31px 0 0 0;"><h3 id="informal-settlements">Informal Settlements</h3></div>
		<div class="row-fluid">
			<div class="span6">
				<p>Mshengu Toilet Hire has the capacity to provide basic portable chemical non-flush toilets to Informal Settlements across the Cape Metropolitan region. The units are serviced on a regular basis and where large scale portable toilets are deployed in one area, janitors and monitors are provided for the upkeep thereof to ensure that the highest levels of health and safety is maintained.</p>
				<p style="margin: 31px 0 0 0;"><b>“Sanitation is Dignity and dignity is a basic human right.”</b></p>
			</div>
			<div class="span6 informal-settlements"><img style="margin:-8px 0 0 124px;" src="/wp-content/uploads/informal-settlements.jpg"/></div>
		</div>
		
		<div class="row-fluid">
			<div class="span12" style="margin: 32px 0 0 -4px; padding-right: 6px;"><img src="/wp-content/uploads/township-view.jpg"/></div>
		</div>
		<div class="row-fluid">
			<div class="span12" style="margin: 30px 0 30px 0;">
			Informal settlement has grown significantly over the past few years, hence sanitation services became a major challenge. Mshengu Toilet Hire specialises in providing sanitation facilities and services to most informal settlements in the Western Cape. Years of experience operating in informal settlements has made the company one of the leading service providers in the industry.
			</div>
		</div>
		
		<div class="row-fluid" style="margin: 11px 0 10px 0;">			
			<div class="row-fluid" >
				<div class="span12" style="margin: 0 0 0 -4px;"><img style="width: 99.3%" src="/wp-content/uploads/services-ribbon.jpg"/></div>
			</div>
		</div>
		
		<div class="row-fluid">
			<div class="span11" style="margin: 30px 0 10px 0;">
				<div class="row-fluid blue-heading"><h3 id="construction">Construction</h3></div>
			</div>
			<div class="row-fluid">
				<div class="span6" style="margin: 0 0 0 -4px;"><img style="width: 83.5%;" src="/wp-content/uploads/construction-site.jpg"/></div>
				<div class="span6" style="margin: 72px 0 0 0;">
					Units are available for commercial and domestic construction sites. Whether you are renovating your home or have a larger commercial construction site, Mshengu Toilet Hire offers portable units for your need.
				</div>
			</div>
		</div>
		
		<div class="row-fluid" style="margin: 30px 0 0 0;">
				<div class="span5" style="margin: 0 0 0 -4px;"><img src="/wp-content/uploads/table-chart.png"/></div>
				<div class="span6"><img style="margin: -65px 0 0 181px ;" src="/wp-content/uploads/mobile-toilet.jpg"/></div>
		</div>
		
		<div class="row-fluid">			
			<div class="row-fluid blue-heading" style="margin: 30px 0 10px 0;"><h3 id="special-events">Special Events</h3></div>			
			<div class="row-fluid">				
				<div class="span6" style="margin: 32px 0 0 0;">
					Mshengu Toilet Hire has options available for special events such as large scale corporate events, festivals, concerts, weddings and sports events. Depending on your service requirements we are able to provide Standard non-flush, flush or Executive flush with handbasin facilities.
				</div>
				<div class="span6"><img style="margin: -45px 0 0 120px;" src="/wp-content/uploads/special-events.jpg"/></div>
			</div>
		</div>
		
		<div class="row-fluid" style="margin: 20px 0 20px 0;">			
			<div class="row-fluid">
				<div class="span12" style="margin: 17px 0 0 -4px;"><img style="width: 99.3%" src="/wp-content/uploads/special-events-ribbon.jpg"/></div>
			</div>
		</div>
		
	</div>
</div>