<!DOCTYPE html>
<html lang="en" style="margin: 0px !important;">
	<head>
		<title><?php bloginfo( 'name' ) ?></title>		
		<link type="text/css" rel="stylesheet" href="<?php bloginfo( 'template_directory' ) ?>/bootstrap/css/bootstrap.min.css"/>
		<link rel="icon" type="image/vnd.microsoft.icon" href="/wp-content/uploads/favicon.ico">
		<link type="text/css" rel="stylesheet" href="<?php bloginfo( 'template_directory' ) ?>/stylesheets/menu.css"/>		 
		
		<?php if ( is_page('request-a-quote')):?> 
			<link type="text/css" rel="stylesheet" href="<?php bloginfo( 'template_directory' ) ?>/stylesheets/datepicker.css"/>
		<?php endif?>
		
		<?php if(is_home()):?>
			<link type="text/css" rel="stylesheet" href="<?php bloginfo( 'template_directory' )?>/stylesheets/home.css"/>					
			<link type="text/css" rel="stylesheet" href="<?php bloginfo( 'template_directory' )?>/stylesheets/liteaccordion.css"/>
		<?php endif?>
		
		<link type="text/css" rel="stylesheet" href="<?php bloginfo( 'template_directory' ) ?>/stylesheets/footer.css"/>				
				
		<?php 
			/*load the slider and other pluins resources resources*/			
			if ( is_page('csi') || is_page('products') || is_page('basic-range') || is_page('standard-range') || is_page('executive-range') || is_page('wheelchair-accessible')){
				wp_head();
			}
		?>
	</head>
	<body style="margin:0 !important;">
		<div class="container">			
			<div class="menu-container">
				<div class="menu-wrapper span7">						
					<?php
					
					 if ( function_exists( clean_custom_menus() ) ) {
						clean_custom_menus();
					}					
										
					?>
				</div>
				<div class="login-wrapper span3">
					<div class="row-fluid">
						<div class="quote span7" style="margin-left: 17px;">
							<!--<a href="request-a-quote"><img src="/wp-content/uploads/request-a-quote-icon.png"> Request-a-Quote</a>--!>
						</div>
						<div class="login span4">
							<a href="http://kmis.mshengutoilethire.co.za/mshengu/app/"><img src="/wp-content/uploads/login-icon.png"> Login</a>
						</div>
					</div>
				</div>				
			</div>
		
		