<div class="row-fluid main-content-container">
	<div class="services-container">		
		<div class="row-fluid blue-heading"><h2>Our History</h2></div>
		<div class="row-fluid">
			<div class="span6">
				<p style="margin: 20px 0 0 0;">Mshengu Toilet Hire was established in 2000 and originated in the township of Gugulethu in the Western Cape S.A.</p>				
				<p style="margin: 20px 0 0 0;">The company has since evolved expanding its sanitation services and products developing itself to take advantage of opportunities in the mainstream of the industry. The company is now recognised as a competent provider of sanitation services and products to the building  and construction industry, special events, government and commerce.</p>
			</div>			
		</div>
		<div class="row-fluid" style="margin: 0 0 0 0;">
			<div class="span12">
				<img style="margin: -206px 0 -20px -48px;; max-width: 1000px;" src="/wp-content/uploads/our-history.png" />
			</div>			
		</div>
	</div>
</div>
		