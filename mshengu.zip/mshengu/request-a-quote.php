<div class="row-fluid main-content-container">		
	<div class="row-fluid blue-heading"><h2>REQUEST A QUOTE</h2></div>
	<div class="row-fluid">
		<div class="span5">
			<div class="row-fluid">
			<img  style="margin: 31px 0 0 0;" src="/wp-content/uploads/quote.jpg">
		</div>
		<div class="row-fluid" style="margin: 31px 0 0 0; border-top: solid 1px rgb(192, 192, 192); border-bottom: solid 1px rgb(192, 192, 192); padding-top: 6px;">
			<p>Please fill in as much information as possible, in order for us to provide you with a quote.</p>
		</div>
		<div class="row-fluid blue-heading" style="margin: 31px 0 0 0;"><h4>CONTACT MSHENGU TOILET HIRE</h4></div>
		<div class="row-fluid" style="margin: 10px 0 0 0;">
			<p style="margin: 0 0 20px 0;">For any further information <br>please contact us on:</p>
			<h4 class="blue-heading">Service Operations:</h4>
			<p>
			Tel: 021 691 3793<br>
			Fax: 021 691 3831<br>
			Email: info@mshengutoilethire.co.za</p>					
		</div>
		</div>
		<div class="span7">
			<div class="row-fluid blue-heading" style="margin: 0 0 10px 0; border-bottom: 1px dotted rgb(192, 192, 192);"><h5>General Details</h5></div>
			<form class="" id="form" action="/thank-you" method="post">
				<input type="hidden" name="reason" value="A Request-a-Quote"/>	
				<input type="hidden" name="mapping" value="requestaquote"/>
				<input type="hidden" value="" id="comboChecker"/>
				<div class="row-fluid">			
					<div class="control-group span6">
						<label class="control-label" for="companyNameNonRequired">Company Name </label>
						<div class="controls">
							<input type="text" name="companyNameNonRequired" id="companyNameNonRequired">
						</div>
					</div>
					<div class="control-group span6">
						<label class="control-label" >VAT Registration Number</label>
						<div class="controls">
							<input type="text" name="vatRegistrationNumberUnrequired">
						</div>
					</div>
				</div>
				
				<div class="row-fluid">
					<div class="control-group span6">
						<label class="control-label" for="contactPersonFirstname">Contact Person Firstname<span class="required">*</span></label>
						<div class="controls">
							<input type="text" name="contactPersonFirstname" id="contactPersonFirstname">
						</div>
					</div>
					<div class="control-group span6">
						<label class="control-label" for="contactPersonLastname">Contact Person Lastname<span class="required">*</span></label>
						<div class="controls">
							<input type="text" name="contactPersonLastname" id="contactPersonLastname">
						</div>
					</div>						
				</div>
				
				<div class="row-fluid">
					<div class="control-group span6">
						<label class="control-label" for="telephoneNumberNonRequired" >Company Tel Number </label>
						<div class="controls">
							<input type="text" name="telephoneNumberNonRequired" id="telephoneNumberNonRequired">
						</div>
					</div>
					<div class="control-group span6">
						<label class="control-label" for="contactNumber">Contact Number <span class="required">*</span></label>
						<div class="controls">
							<input type="text" name="contactNumber" id="contactNumber">
						</div>
					</div>
				</div>
				
				<div class="row-fluid">
					<div class="control-group span6">
						<label class="control-label" for="faxNumber">Fax Number</label>
						<div class="controls">
							<input type="text" name="faxNumber" id="faxNumber">
						</div>
					</div>
					<div class="control-group span6">
						<label class="control-label" for="email">Email <span class="required">*</span></label>
						<div class="controls">
							<input type="text" id="email" name="email">
						</div>
					</div>
				</div>
				
				<div class="row-fluid">
					<div class="control-group span6">
						<label class="control-label" for="billingAddress" >Billing Address <span class="required">*</span></label>
						<div class="controls">
							<textarea style="max-width: 220px" rows="3" name="billingAddress" id="billingAddress"></textarea>
						</div>
					</div>
					<div class="control-group span6">
						<label class="control-label" for="deliveryAddress">Delivery Address  <span class="required">*</span> <input style="margin-top:-2px;" type="checkbox"  id="sameAsBillingAddress" /> Same as Billing Address</label>
						<div class="controls">
							<textarea style="max-width: 220px" rows="3" name="deliveryAddress" id="deliveryAddress"></textarea>
						</div>
					</div>
				</div>
				
				<div class="row-fluid blue-heading" style="margin: 0 0 10px 0; border-bottom: 1px dotted rgb(192, 192, 192);"><h5>Event Details</h5></div>
				<div class="row-fluid" style="font-size: 12px;"><i>Choose either of the following: </i><span class="required">*</span></div>
				
				<div class="row-fluid">
					<label class="radio span3">
						<input type="radio" name="eventType" id="optionsRadios1" value="Contract" >	
						Contract  
					</label>
					<label class="radio span3">
						<input type="radio" name="eventType" id="optionsRadios2" value="Construction">
						Construction
					</label>
					<label class="radio span3">
						<input type="radio" name="eventType" id="optionsRadios3" value="Special Event">
						Special Event
					</label>
					<label class="radio span3">
						<input type="radio" name="eventType" id="optionsRadios3" value="Private">
						Private
					</label>
					<label for="eventType" class="error" style="margin-bottom: 10px; display:none;">Please choose one.</label>
				</div>
				
				<div class="row-fluid">			
					<div class="control-group span6">
						<label class="control-label" for="eventName">Event Name </label>
						<div class="controls">
							<input type="text" name="eventName" id="eventName" >
						</div>
					</div>
					<div class="control-group span6">
						<div class="input-prepend date" id="dp3" data-date="12-02-2012" data-date-format="dd-mm-yyyy">
							<label class="control-label" for="eventDate">Event Date  <span class="required">*</span></label>
							<span class="add-on"><i class="icon-calendar"></i></span>
							<input type="text" class="datepicker span12" value="" id="eventDate" name="eventDate">
							
						</div>
					</div>
				</div>
				
				<div class="row-fluid">
		                    <div class="control-group span6">
		                        <label class="control-label" for="toiletsRequired1">Toilets Required <span class="required">*</span></label>
		                        <div class="controls">
		                            <select class="span12 requiredCombo" name="toiletsRequired1" id="toiletsRequired1">
		                                <option value="">--Please Choose an Option--</option>
						<option value="Basic Atlas">Basic Atlas</option>
						<option value="Standard Non-Flush">Standard Non-Flush</option>
						<option value="Executive Flush">Executive Flush</option>
						<option value="Executive Flush & Hand Basin">Executive Flush & Hand Basin</option>
						<option value="Wheel Chair Accessible">Wheel Chair Accessible</option>
		                            </select>
		                        </div>
		                    </div>
		                    <div class="control-group span6">
		                        <label class="control-label" for="quantityRequired1">Quantity Required <span class="required">*</span></label>
		                        <div class="controls">
		                            <input type="text" id="quantityRequired1" name="quantityRequired1">
		                        </div>
		                    </div>
		                </div>
		
		                <div class="row-fluid">
		                    <div class="control-group span6">
		                        <label class="control-label" for="toiletsRequired2">Additional Toilets Required </label>
		                        <div class="controls">
		                            <select class="requiredCombo" name="toiletsRequired2" id="toiletsRequired2">
		                                <option value="">--Please Choose an Option--</option>
						<option value="Basic Atlas">Basic Atlas</option>
						<option value="Standard Non-Flush">Standard Non-Flush</option>
						<option value="Executive Flush">Executive Flush</option>
						<option value="Executive Flush & Hand Basin">Executive Flush & Hand Basin</option>
						<option value="Wheel Chair Accessible">Wheel Chair Accessible</option>
		                            </select>
		                        </div>
		                    </div>
		                    <div class="control-group span6">
		                        <label class="control-label" for="quantityRequired2">Quantity Required </label>
		                        <div class="controls">
		                            <input type="text" id="quantityRequired2" name="quantityRequired2">
		                        </div>
		                    </div>
		                </div>
		
		                <div class="row-fluid">
		                    <div class="control-group span6">
		                        <label class="control-label" for="toiletsRequired3">Additional Toilets Required </label>
		                        <div class="controls">
		                            <select class="requiredCombo" name="toiletsRequired3" id="toiletsRequired3">
		                                <option value="">--Please Choose an Option--</option>
						<option value="Basic Atlas">Basic Atlas</option>
						<option value="Standard Non-Flush">Standard Non-Flush</option>
						<option value="Executive Flush">Executive Flush</option>
						<option value="Executive Flush & Hand Basin">Executive Flush & Hand Basin</option>
						<option value="Wheel Chair Accessible">Wheel Chair Accessible</option>
		                            </select>
		                        </div>
		                    </div>
		                    <div class="control-group span6">
		                        <label class="control-label" for="quantityRequired3">Quantity Required </label>
		                        <div class="controls">
		                            <input type="text" id="quantityRequired3" name="quantityRequired3"/>
		                        </div>
		                    </div>
		                </div>
				
				<div class="row-fluid">					
					<div class="control-group span6">
						<label class="control-label" for="numberOfToiletRolls">Number of Toilet Rolls </label>
						<div class="controls">
							<input type="text" id="numberOfToiletRolls" name="numberOfToiletRolls"/>
						</div>
					</div>
					<div class="control-group span6">
						<label class="control-label" for="numberOfJanitors">Number of Janitors </label>
						<div class="controls">
							<input type="text" id="numberOfJanitors" name="numberOfJanitors"/>
						</div>
					</div>
				</div>
				
				<div class="row-fluid">			
					<div class="control-group span3">
						<label class="control-label" >Service Frequency</label>
					</div>
					<div class="control-group span6 offset3">
						<label class="span2">
							<label style="margin-left: -6px;">Mon</label>
							 <input class="frequencyCheckbox" type="checkbox" name="serviceFrequencyMon" id="serviceFrequencyMon" value="false" />	
						</label>
						<label style="margin-left: -6px;" class="span1">
							<label style="margin-left: -4px;">Tue</label>
							<input class="frequencyCheckbox" type="checkbox" name="serviceFrequencyTue" id="serviceFrequencyTue" value="false" />	
						</label>
						<label style="margin-left: 17px;" class="span2">
							<label style="margin-left: -7px;">Wed</label>
							<input class="frequencyCheckbox" type="checkbox" name="serviceFrequencyWed" id="serviceFrequencyWed" value="false" />	
						</label>
						<label style="margin-left: -5px;" class="span1">
							<label style="margin-left: -7px;">Thur</label>
							<input class="frequencyCheckbox" type="checkbox" name="serviceFrequencyThur" id="serviceFrequencyThur" value="false" />	
						</label>
						<label style="margin-left: 17px;" class="span2">
							<label style="margin-left: -1px;">Fri</label>
							<input class="frequencyCheckbox" type="checkbox" name="serviceFrequencyFri" id="serviceFrequencyFri" value="false" />	
						</label>
						<label style="margin-left: -6px;" class="span1">
							<label style="margin-left: -2px;">Sat</label>
							<input class="frequencyCheckbox" type="checkbox" name="serviceFrequencySat" id="serviceFrequencySat" value="false" />	
						</label>
						<label style="margin-left: 17px;" class="span2">
							<label style="margin-left: -3px;">Sun</label>
							<input class="frequencyCheckbox" type="checkbox" name="serviceFrequencySun" id="serviceFrequencySun" value="false" />	
						</label>
					</div>
				</div>
				
				<div class="row-fluid">			
					<div class="control-group span6">
						<div class="input-prepend date" id="dp3" data-date="12-02-2012" data-date-format="dd-mm-yyyy">
							<label class="control-label" for="deliveryDate">Delivery Date <span class="required">*</span></label>
							<span class="add-on"><i class="icon-calendar"></i></span>
							<input type="text" class="datepicker span12" value="" id="deliveryDate" name="deliveryDate">
						</div>
					</div>
					<div class="control-group span6">
						<div class="input-prepend date" id="dp3" data-date="12-02-2012" data-date-format="dd-mm-yyyy">
							<label class="control-label" for="collectionDate">Collection Date <span class="required">*</span></label>
							<span class="add-on"><i class="icon-calendar"></i></span>
							<input type="text" class="datepicker span12" value="" name="collectionDate" id="collectionDate">							
						</div>
					</div>
				</div>
				
				<div class="row-fluid">			
					<div class="control-group span3">
						<label class="control-label" for="daysRental" >Days Rental</label>
					</div>
					<div class="control-group span9">
						<div class="controls">
							<input type="text" class="offset4" name="daysRental" id="daysRental">
						</div>
					</div>
				</div>
				
				<div class="row-fluid">			
					<div class="control-group span3">
						<label class="control-label" >Comments</label>
					</div>
					<div class="control-group span9">
						<div class="controls">
							<textarea style="max-width: 289px; width: 289px;" name="comment" rows="4" class="offset2 span10" placeholder="Your message must be greater than 20 characters"></textarea>
						</div>
					</div>
				</div>
				
				<div class="row-fluid" style="margin: 31px 0 0 0; text-decoration: underline;"><b><a href="/terms-of-use">Terms of Hire</a></b></div>

				<div class="row-fluid" style="margin: 20px 0 20px 0;">			
					<div class="control-group span5">
						<label class="checkbox inline">
							<input type="checkbox" id="acceptConditions" name="acceptConditions" value="acceptConditions"> 
							<span>I accept the terms as listed</span>
							<label for="acceptConditions" class="error" style="margin-bottom: 10px; display:none;">You need to accept the terms and conditions.</label>
						</label>
					</div>
					<div class="control-group span7">							
							<button type="submit" class="span4 btn btn-primary">SUBMIT</button>
							<button type="button" class="span4 btn reset-btn">RESET</button>							
					</div>
				</div>
				
			</form>
		</div>
	
	</div>
</div>