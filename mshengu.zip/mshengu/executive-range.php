<div class="row-fluid main-content-container">
	<div class="services-container">
		<div class="row-fluid blue-heading"><h2>Executive Range</h2></div>
		<div class="row-fluid" style="margin: 24px 0 0 0;">
			<div class="span6 left-blue-border" style="min-height: 335px">
				<p>The Standard range can be upgraded to our Executive range of portable toilets which can be supplied with a variety of optional additional features such as:</p>
				<p style="margin: 31px 0 0 0;">» Flush Mechanism</p>
				<p style="margin: 31px 0 0 0;">» Hand Basin (Executive Plus Option)</p>				
			</div>
			<div class="span6">
				<?php if( function_exists( 'sliceshow_slideshow' ) ) { sliceshow_slideshow( 148 ); } ?>
			</div>
		</div>
		
		<div class="row-fluid" style="margin: 31px 0 0 0;">
			<div class="span6">
				<img style="margin: 0 0 0 0; width: 89%;" src="/wp-content/uploads/executive-table-1.png" />
			</div>
			<div class="span6">
				<img style="margin: 0 0 0 32px; width: 89%;" src="/wp-content/uploads/executive-table-2.png" />
			</div>
		</div>
		
		<div class="row-fluid" style="margin: 31px 0 31px 0;">
			<div class="span6">
				<img style="margin: 0 0 0 0; width: 89%;" src="/wp-content/uploads/executive-table-3.png" />
			</div>
			<div class="span6">
				<img style="margin: 0 0 0 32px; width: 89%;" src="/wp-content/uploads/executive-table-4.png" />
			</div>
		</div>
	</div>
</div>