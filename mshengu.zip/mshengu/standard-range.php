<div class="row-fluid main-content-container">
	<div class="services-container">
		<div class="row-fluid blue-heading"><h2>Standard Range</h2></div>
		<div class="row-fluid" style="margin: 24px 0 0 0;">
			<div class="span6 left-blue-border">
				<p>Our standard range of portable toilets represents an authentic advancement in the portable sanitation industry. The range is a blend of practical features and a captivating design.</p>
				<p style="margin: 31px 0 0 0;">The Standard Range design has been specifically developed to achieve ultra smooth surfaces which are easy to wash. Construction and assembly of the wall panels  with overlapping systems means that rivets are concealed, enabling for cleaning to be more practical and the inside of the unit more refined and stylish.</p>
				
				<p style="margin: 31px 0 0 0;">Our Standard Range is supplied in the NON-FLUSH option only.</p>
			</div>
			<div class="span6">
				<?php if( function_exists( 'sliceshow_slideshow' ) ) { sliceshow_slideshow( 121); } ?>
			</div>
		</div>
		
		<div class="row-fluid" style="margin: 31px 0 0 0;">
			<div class="span6">
				<img style="margin: 0 0 0 0;  width: 89%;" src="/wp-content/uploads/standard-table-1.png" />
			</div>
			<div class="span6">
				<img style="margin: 0 0 0 32px; width: 89%;" src="/wp-content/uploads/standard-table-2.png" />
			</div>
		</div>
		
		<div class="row-fluid" style="margin: 31px 0 31px 0;">
			<div class="span6">
				<img style="margin: 0 0 0 0; width: 89%;" src="/wp-content/uploads/standard-table-3.png" />
			</div>
			<div class="span6">
				<img style="margin: 0 0 0 32px; width: 89%;" src="/wp-content/uploads/standard-table-4.png" />
			</div>
		</div>
	</div>
</div>