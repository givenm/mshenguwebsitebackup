<?php
	get_template_part('basic-range');
?>	