<div class="row-fluid main-content-container">
	<div class="services-container">		
		<div class="row-fluid blue-heading"><h2>Corporate Social Initiatives</h2></div>
		<div class="row-fluid">
			<div class="span12">
				<p style="margin: 20px 0 0 0;">Aligned to our values of Leadership, Teamwork and Superior Customer Services, Mshengu Toilet Hire wishes to be one of the leading socially responsible organisations involved in the reduction of poverty and social problems, through partnerships with local community organisations for the development and upliftment of communities it serves. </p>				
				<p style="margin: 20px 0 0 0;">The company also contributes actively to the upliftment of historically disadvantaged communities in which we operate, through integrated, efficient and effective social investment programmes in the identified focus areas.</p>							
				<p style="margin: 20px 0 0 0;"><b>Our key priority areas:</b></p>
				<p style="margin: 10px 0 0 0;">
					<ul>
						<li>Education, capacity building and skills development for targeted communities</li>
						<li>Job-creation programmes/projects, with the primary focus on youth, women and people with disabilities;</li>
						<li>Infrastructure development with a focus on schools and sports clubs in local communities;</li>						
					</ul>
				</p>
				<p style="margin: 20px 0 0 0;"><b>Some of Our Key Initiatives:</b></p>
			</div>
		</div>
		<div class="row-fluid" style="border: 1px solid #efefef; margin: 17px 0 0 0; height: 300px; padding-top: 46px; overflow: hidden; position: relative;">
			<div class="backward" style="z-index:1100; width: 35px; height: 121px; position: absolute; left:0; top: 38%;">
				<img src="/wp-content/uploads/csi-backward.png" alt="Next"/>
			</div>			
			<div class="forward"  style="z-index:1100; width: 35px; height: 121px; position: absolute; right:0; top: 38%;">
				<img src="/wp-content/uploads/csi-forward.png" alt="Forward"/>
			</div>
				
			<div class="row-fluid csi-slider" style="width:1358px; padding-right: 20px; position: relative;">	
				<div class="span4" style="position:relative">					
					<div id="flipbox-1" class="" style="visibility: visible; width: 84%; margin-left: 46px; width:395px;">
						<img class="flip-hover" style="z-index:60" id="flip-1" src="/wp-content/uploads/sport-1.png" />										
					</div>
					
					<div id="flipbox-1-temp-1" class="" style="display: none">
						<img class="flip-hover" id="flip-1-revert" style="z-index:60" src="/wp-content/uploads/sport-2.png" />										
					</div>
					<div id="flipbox-1-temp-2" class="" style="display: none">
						<img class="flip-hover" id="flip-1" style="z-index:60" src="/wp-content/uploads/sport-1.png" />										
					</div>
					
				</div>			
				
				<div class="span4" style="position:relative">
					<div id="flipbox-2" class="" style="visibility: visible; width: 84%; margin-left: 22px; width:395px;">
						<img class="flip-hover" id="flip-2" style="z-index:60" src="/wp-content/uploads/winter-blanket-1.png" />									
					</div>
					
					<div id="flipbox-2-temp-1" class="" style="display: none">
						<img class="flip-hover" id="flip-2-revert" style="z-index:60" src="/wp-content/uploads/winter-blanket-2.png" />					
					</div>
					<div id="flipbox-2-temp-2" class="" style="display: none">
						<img class="flip-hover" id="flip-2" style="z-index:60" src="/wp-content/uploads/winter-blanket-1.png" />
					</div>
					
				</div>
				
				<div class="span4" style="position:relative">
					<div id="flip-slider" style="margin-left: -29px; margin-top: 6px;">
						<?php if( function_exists( 'sliceshow_slideshow' ) ) { sliceshow_slideshow( 326 ); } ?>						
					</div>
					<div class="flip-hover" id="flip-3" style="position: absolute; width:381px; height: 70px; padding-top: 0px;margin-top: -71px; margin-left: 5px; z-index: 1000;"></div>
					
					<div id="flipbox-3-temp-1" class="" style="display: none">
						<img class="flip-hover" id="flip-3-revert" style="z-index:60" src="/wp-content/uploads/soccer.png" />					
					</div>					
					
				</div>
			</div>
		</div>			
	</div>
</div>